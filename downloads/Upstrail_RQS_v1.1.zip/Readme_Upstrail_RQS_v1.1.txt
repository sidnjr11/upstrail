📘 Upstrail Reorder Quantity Suggestor – README (v1.1)

Overview:
The Upstrail Reorder Quantity Suggestor is a lightweight Excel-based planning plugin that helps supply chain planners determine:
✅ When to reorder a product
✅ How much to reorder

Using current inventory, lead time, safety stock, sales history, and (optionally) forecasted demand, the tool calculates a Reorder Point (ROP) and flags SKUs for replenishment only when needed.

---

📂 Sheets and Structure:

- Home:
  Control center where you set toggles and inputs like:
    • Use Safety Stock (TRUE/FALSE)
    • Use Lead Time (TRUE/FALSE)
    • Use Forecast Instead of Sales (TRUE/FALSE)
    • Use EOQ if entered (TRUE/FALSE)
    • Average Demand Window (7, 14, 30 days)
    • Default Safety Stock (units)
    • Default Lead Time (days)

- Inventory:
  One row per SKU. Required columns:
    • SKU, Product Name, Current Stock
    • Optional: Safety Stock, Lead Time, EOQ

- Sales:
  Historical sales records (SKU, Date, Quantity Sold)

- Forecast (optional):
  Future demand expectations by period (SKU, Start Date, End Date, Quantity)

---

🔍 Logic & Calculation:

The plugin uses the following logic:

1. **Average Daily Demand (Units/Day)**:
   - If Forecast toggle is ON → forecast quantity ÷ forecast period (days)
   - Else → sum of sales in the last X days ÷ X

2. **Reorder Point (ROP in Units)**:
   ```
   ROP = (Avg Daily Demand × Lead Time) + Safety Stock
   ```

3. **Decision Logic**:
   - If Current Stock ≥ ROP → No reorder needed
   - If Current Stock < ROP:
     • If EOQ is filled and enabled → Suggested Qty = EOQ
     • Else → Suggested Qty = ROP – Current Stock

4. **Reorder Flag**:
   - Flag = YES if reorder is needed
   - Flag = NO if stock is sufficient

---

📊 Output Columns (ReorderPlan):

- SKU
- Product Name
- Current Stock
- Avg Daily Demand (units/day)
- Lead Time (days)
- Safety Stock (units)
- EOQ (Optional)
- Reorder Point (units)
- Reorder Flag (YES/NO)
- Suggested Reorder Qty (units)

---

✅ How to Use:

1. Click 'Generate Template' to get fresh input sheets.
2. Fill your data or use sample entries.
3. Set your toggles and defaults on the Home sheet.
4. Click 'Validate Data' to check for any errors or inconsistencies.
5. Click 'Run Reorder Calculator' to generate the ReorderPlan.
6. Click 'Export to PDF' to generate a shareable version.
7. All actions are logged in the Log sheet.

---

🧠 FAQs:

Q: What happens if I have both Sales and Forecast data?
A: The plugin uses one at a time. If the "Use Forecast" toggle is ON, it ignores Sales.

Q: What if EOQ is filled but the toggle is OFF?
A: EOQ will be ignored unless explicitly enabled.

Q: Are all units in days or units?
- Lead Time: Days
- Avg Demand: Units per day
- Safety Stock: Units
- ROP: Units
- Suggested Qty: Units
- EOQ: Units

Q: What if some values are blank?
- Safety Stock and Lead Time use defaults if blank.
- Demand will be 0 if no forecast or sales data is found.

---

🛡️ Logs:
Every button press (Calculate, Export, Validate, Generate) is logged with:
• Timestamp
• User
• Action

---

📩 Support:
Website: https://www.upstrail.com  
Email: siddharth@upstrail.com

Generated on: 2025-05-25
