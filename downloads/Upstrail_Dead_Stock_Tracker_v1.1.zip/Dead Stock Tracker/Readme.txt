==============================
Upstrail – Dead Stock Tracker
==============================

Version: 1.1  
File Type: Excel Macro-Enabled Workbook (.xlsm)  
Developed by: Upstrail  
Website: https://upstrail.com  
Contact: siddharth@upstrail.com

---

📦 What This Tool Does:
-----------------------
This Excel-based plugin helps identify slow-moving or dead inventory based on sales activity. 
It calculates how long it's been since each SKU was last sold, estimates holding cost, categorizes aging, and suggests 
next steps using a "Recommended Action" field.

The result is a clean, actionable report to help planners reduce working capital and drive stock efficiency.

---

🚀 How to Use:
--------------
1. Open the file and **enable macros** when prompted.
2. On the 'Home' sheet, click **"Generate Template"** to create 'Inventory' and 'Sales' sheets.
3. Enter your actual inventory and sales data in the respective sheets.
4. Click **"Run Tracker"** to generate a new report: 'DeadStockReport'.
5. (Optional) Click **"Export to PDF"** to generate a sharable file.
6. Click **"View Instructions"** to regenerate this README at any time.

---

🔍 Recommended Action Logic:
----------------------------
Based on how long it has been since the item last sold:

| Aging Category | Action                              |
|----------------|--------------------------------------|
| 0–30 Days      | Monitor                              |
| 31–60 Days     | Review / Promote                     |
| 61–90 Days     | Plan Discount                        |
| 91–180 Days    | Clearance Recommended                |
| 180+ Days      | Write-off / Urgent Clearance         |
| No Sales       | Never Sold – Investigate             |

---

📋 Important Guidelines:
-------------------------
- **Do not rename** the sheets 'Inventory' or 'Sales' — the macros depend on these exact names.
- Quantity and date inputs are **validated** to prevent errors (e.g., negative values, future dates).
- Do not change or delete the headers in the template.
- Dead stock is calculated **only for SKUs present in the Inventory sheet**.

---

✅ Additional Features:
-----------------------
- Conditional formatting by aging bucket
- Filters and autofit enabled in the report
- One-click PDF export
- Sample data available for testing
- Works entirely within Excel — no external tools required

---

💬 Support:
-----------
Need help or want to customize this tool for your business?

Contact: siddharth@upstrail.com  
Website: https://upstrail.com

Thank you for using Upstrail.
